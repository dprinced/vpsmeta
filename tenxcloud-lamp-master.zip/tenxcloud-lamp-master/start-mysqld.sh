#!/bin/bash
exec mysqld_safe
